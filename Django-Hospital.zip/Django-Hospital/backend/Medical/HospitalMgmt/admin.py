from django.contrib import admin
from .models import Role,Users,Admin,Doctor,Patient,Nurse,Appointment,Email
admin.site.register(Role)
admin.site.register(Users)
admin.site.register(Admin)
admin.site.register(Doctor)
admin.site.register(Patient)
admin.site.register(Nurse)
admin.site.register(Appointment)
admin.site.register(Email)



# Register your models here.
