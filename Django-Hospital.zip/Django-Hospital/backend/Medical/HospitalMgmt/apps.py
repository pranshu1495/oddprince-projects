from django.apps import AppConfig


class HospitalmgmtConfig(AppConfig):
    name = 'HospitalMgmt'
