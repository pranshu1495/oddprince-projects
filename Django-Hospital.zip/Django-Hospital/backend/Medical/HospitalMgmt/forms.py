from django.forms import forms
from .models import Doctor

# class RoleForm(forms.Form):
#     class Meta:
#         model=Role
#         fields="__all__"
#
# class UserForm(forms.Form):
#     class Meta:
#         model=Users
#         fields="__all__"

class DoctorForm(forms.Form):
    class Meta:
        model=Doctor
        fields="__all__"
