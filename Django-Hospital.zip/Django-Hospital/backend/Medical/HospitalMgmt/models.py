from django.db import models


# Create your models here.

class Role(models.Model):
    role_name = models.CharField(max_length=20)
    role_desc = models.TextField(max_length=100)
    def __str__(self):
        return self.role_name

class Users(models.Model):
    role=models.ForeignKey(Role,on_delete=models.CASCADE)
    user_name=models.CharField(max_length=50)
    user_password=models.CharField(max_length=20)
    user_mobile=models.CharField(max_length=12,default=int)
    user_email=models.EmailField()
    user_address=models.TextField(max_length=100)
    def __str__(self):
        return self.user_name

class Doctor(models.Model):
    doc_name=models.CharField(max_length=50)
    doc_email=models.EmailField()
    doc_mobile=models.CharField(max_length=12,default=int)
    doc_spec=models.CharField(max_length=100)
    doc_address=models.TextField(max_length=200)
    def __str__(self):
        return self.doc_name

class Patient(models.Model):
    pat_name=models.CharField(max_length=50)
    pat_email=models.EmailField()
    pat_mobile=models.CharField(max_length=12,default=int)
    pat_address=models.TextField(max_length=100)
    #doctor=models.ForeignKey(Doctor,on_delete=models.CASCADE,default=str)
    def __str__(self):
        return self.pat_name

class Nurse(models.Model):
    #patient=models.ForeignKey(Patient,on_delete=models.CASCADE)
    #doctor=models.ForeignKey(Doctor,on_delete=models.SET_NULL,null=True)
    nur_name=models.CharField(max_length=50)
    nur_email=models.EmailField()
    nur_mobile=models.CharField(max_length=12,default=int)
    nur_address=models.TextField(max_length=100)
    def __str__(self):
        return self.nur_name

class Admin(models.Model):
    admin_name=models.CharField(max_length=50,default=str)
    user=models.ForeignKey(Users,on_delete=models.CASCADE)
    doctor=models.ForeignKey(Doctor,on_delete=models.CASCADE,related_name='doc')
    patient=models.ForeignKey(Patient,on_delete=models.CASCADE)
    nurse=models.ForeignKey(Nurse,on_delete=models.CASCADE)
    def __str__(self):
        return self.admin_name

class Appointment(models.Model):
    doctor=models.ForeignKey(Doctor,on_delete=models.CASCADE)
    patient=models.ForeignKey(Patient,on_delete=models.CASCADE)
    app_date=models.DateField()
    app_time=models.TimeField()

    def __str__(self):
        return self.doctor.doc_name+"--"+self.patient.pat_name

class Email(models.Model):
    mail_from=models.EmailField()
    mail_to=models.EmailField()
    mail_subject=models.CharField(max_length=100)
    mail_body=models.TextField(max_length=500)
    mail_attach=models.FileField()

    def __str__(self):
        return self.mail_from+"--"+self.mail_to














