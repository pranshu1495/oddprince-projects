from django.contrib import admin
from django.urls import path
from . import views


app_name='HospitalMgmt'


urlpatterns = [
    # #Get and Delete Urls
    # # path('role/',views.roleList.as_view()),
    # path('view-user/',views.ViewUser.as_view()),
    # path('view-user/<int:pk>/',views.ViewUser.as_view()),
    path('view-doctor/',views.DoctorListView.as_view()),
    path('view-doctor/<int:pk>/', views.DoctorDetailView.as_view()),
    path('view-patient/', views.ParientListView.as_view()),
    path('view-patient/<int:pk>/', views.PatientDetailView.as_view()),
    path('view-nurse/', views.NurseListView.as_view()),
    path('view-nurse/<int:pk>/', views.NurseDetailView.as_view()),
    # path('view-appointment/',views.ViewAppointment.as_view()),
    # path('view-appointment/<int:pk>/',views.ViewAppointment.as_view()),
    # path('view-email/',views.ViewEmail.as_view()),
    # path('view-email/<int:pk>/',views.ViewEmail.as_view()),
    #
    # #Create Urls
    # path('create-user/', views.CreateUser.as_view()),
    path('create-doctor/', views.DoctorCreateView.as_view()),
    path('create-patient/', views.PatientCreateView.as_view()),
    path('create-nurse/', views.NurseCreateView.as_view()),
    # path('create-appointment/', views.CreateAppointement.as_view()),
    # path('create-email/', views.CreateEmail.as_view()),
    #
    #
    # #Update Urls
    # path('update-user/<int:pk>/',views.UpdateUser.as_view()),
    path('update-doctor/<int:pk>/',views.DoctorUpdateView.as_view()),
    path('update-patient/<int:pk>/', views.PatientUpdateView.as_view()),
    path('update-nurse/<int:pk>/', views.NurseUpdateView.as_view()),
    # path('update-appointment/<int:pk>/', views.UpdateAppointment.as_view()),

    #Delete Urls
     path('delete-doctor/<int:pk>/', views.DoctorDeleteView.as_view()),
]

