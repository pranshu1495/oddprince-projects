from .Serializer import doctorSerializer,patientSerializer,nurseSerializer,appointmentSerializer,userSerializer,emailSerializer
from .models import Role,Users,Doctor,Patient,Nurse,Appointment,Email
from rest_framework import permissions
from rest_framework.generics import(
ListAPIView,
RetrieveAPIView,
CreateAPIView,
DestroyAPIView,
UpdateAPIView
)
# Create your views here.
#Doctor CRUD
class DoctorListView(ListAPIView):
    queryset = Doctor.objects.all()
    serializer_class = doctorSerializer
    permission_classes = (permissions.AllowAny,)

class DoctorDetailView(RetrieveAPIView):
    queryset = Doctor.objects.all()
    serializer_class = doctorSerializer
    permission_classes = (permissions.AllowAny,)

class DoctorCreateView(CreateAPIView):
    queryset = Doctor.objects.all()
    serializer_class = doctorSerializer
    permission_classes = (permissions.AllowAny,)

class DoctorUpdateView(UpdateAPIView):
    queryset = Doctor.objects.all()
    serializer_class = doctorSerializer
    permission_classes = (permissions.AllowAny,)

class DoctorDeleteView(DestroyAPIView):
    queryset = Doctor.objects.all()
    serializer_class = doctorSerializer
    permission_classes = (permissions.AllowAny,)

#Patient CRUD
class ParientListView(ListAPIView):
    queryset = Patient.objects.all()
    serializer_class = patientSerializer
    permission_classes = (permissions.AllowAny,)

class PatientDetailView(RetrieveAPIView):
    queryset = Patient.objects.all()
    serializer_class = patientSerializer
    permission_classes = (permissions.AllowAny,)

class PatientCreateView(CreateAPIView):
    queryset = Patient.objects.all()
    serializer_class = patientSerializer
    permission_classes = (permissions.AllowAny,)

class PatientUpdateView(UpdateAPIView,DestroyAPIView):
    queryset = Patient.objects.all()
    serializer_class = patientSerializer
    permission_classes = (permissions.AllowAny,)

# class PatientDeleteView(DestroyAPIView):
#     queryset = Patient.objects.all()
#     serializer_class = patientSerializer
#     permission_classes = (permissions.IsAuthenticated,)

#Nurse CRUD
class NurseListView(ListAPIView):
    queryset = Nurse.objects.all()
    serializer_class = nurseSerializer
    permission_classes = (permissions.AllowAny,)

class NurseDetailView(RetrieveAPIView):
    queryset = Nurse.objects.all()
    serializer_class = nurseSerializer
    permission_classes = (permissions.AllowAny,)

class NurseCreateView(CreateAPIView):
    queryset = Nurse.objects.all()
    serializer_class = nurseSerializer
    permission_classes = (permissions.AllowAny,)

class NurseUpdateView(UpdateAPIView,DestroyAPIView):
    queryset = Nurse.objects.all()
    serializer_class = nurseSerializer
    permission_classes = (permissions.AllowAny,)





















